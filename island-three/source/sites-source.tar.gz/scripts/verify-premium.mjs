// Run: node scripts/verify-premium.mjs /absolute/path/to/three.module.mjs
// Supply the pinned r180 ES module, with its three.core import resolvable.
// Numerical scene verification only: no browser, rendered-image or FPS claims.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';

if (!process.argv[2]) throw new Error('Pass the local Three.js r180 module path.');
const THREE = await import(pathToFileURL(process.argv[2]).href);
assert.equal(THREE.REVISION, '180');
const html = fs.readFileSync(new URL('../dist/index.html', import.meta.url), 'utf8');
const source = html.match(/<script type="module">([\s\S]*?)<\/script>/)[1]
  .replace(/^\s*import[^\n]*\n/gm, '').replace(/\n\s*buildInterface\(\);\s*init\(\);\s*$/, '\n');
const selection = new Proxy({}, { get: () => () => selection });
const context = vm.createContext({ THREE, performance, console, setTimeout, clearTimeout,
  window: { matchMedia: () => ({ matches: false }) }, document: { getElementById: () => ({}) },
  d3: { select: () => selection, selectAll: () => selection } });
const run = code => vm.runInContext(code, context, { timeout: 60000 });
run(source);
assert.deepEqual(JSON.parse(run('JSON.stringify({view:state.view,cut:state.openingDeg,motion:state.motion,cycle:state.cycle})')),
  { view: 'surface', cut: 0, motion: false, cycle: true });
run(`renderer={shadowMap:{needsUpdate:false}};
  scene=new THREE.Scene();scene.fog=new THREE.Fog(0,9,78);
  camera=new THREE.PerspectiveCamera(45,16/9,0.0008,500); screenScale.value=1080;
  colony=new THREE.Group();scene.add(colony);
  for(let i=0;i<3;i++){const light=makeSolarLight();solarLights.push(light);scene.add(light,light.target);}
  for(let i=0;i<3;i++){const light=makeSolarLight(true);nearSolarLights.push(light);scene.add(light,light.target);}
  colony.add(buildEndcap(),buildAxisInfrastructure(),buildMirrors());`);

const cuts = [];
for (const cut of [0, 1, 108, 160]) {
  run(`state.openingDeg=${cut}; rebuildColonySurfaces(); scene.updateMatrixWorld(true);`);
  const data = run('({cells:detailCells,root:colony,traffic:bridgeTraffic,cap:nearEndcap})');
  assert.equal(data.cap.visible, cut === 0);
  assert.equal(new Set(data.cells.map(cell => cell.mesh)).size, data.cells.length);
  let instances = 0;
  data.root.traverse(mesh => {
    if (!mesh.isInstancedMesh) return;
    instances += mesh.count;
    assert.ok([...mesh.instanceMatrix.array].every(Number.isFinite));
    for (const attribute of Object.values(mesh.geometry.attributes)) {
      assert.ok([...attribute.array].every(Number.isFinite));
      if (attribute.isInstancedBufferAttribute) assert.equal(attribute.count, mesh.count);
    }
  });
  for (const cell of data.cells) {
    assert.ok(cell.mesh.parent, 'No stale LOD mesh after cut rebuild');
    assert.ok(cell.mesh.frustumCulled);
    assert.ok(!cell.bounds.isEmpty());
    assert.ok(Number.isFinite(cell.mesh.boundingSphere.radius));
    for (const [name, attribute] of Object.entries(cell.high.attributes)) {
      if (attribute.isInstancedBufferAttribute) assert.equal(cell.low.attributes[name].count, cell.mesh.count);
    }
  }
  run('updateBridgeTraffic(0.02)');
  for (const car of data.traffic) {
    for (const key of ['bodies', 'roofs', 'heads', 'tails', 'wheels']) {
      assert.ok(car[key].parent, 'Animated instance batch must survive partition');
    }
  }
  cuts.push({ cut, instances, cells: data.cells.length });
}

run('state.openingDeg=0;rebuildColonySurfaces();');
// Spatial coordination: test the occupied plot envelope, not only building centers.
const settlements = run(`(()=>{
  let samples=0;const failures=[];
  for(const r of habitatGroup.userData.buildingRecords){
    for(const a of [-1,0,1])for(const b of [-1,0,1]){
      const dx=a*r.width*.66,ds=b*r.depth*.63,yaw=r.yaw||0;
      const x=r.x+dx*Math.cos(yaw)-ds*Math.sin(yaw),theta=r.theta-(dx*Math.sin(yaw)+ds*Math.cos(yaw))/WORLD.radius;
      if(isWater(x,theta,0.015)||transportCorridor(x,theta,0)||districtAt(x,theta)?.park)failures.push('Plot intersects a protected corridor');
      if(WORLD.radius-r.surface<elevationAt(x,theta)+0.0029)failures.push('Terrain penetrates a building platform');
      samples++;
    }
  }
  for(const route of ruralRoutes){
    const center=Math.PI/6+route.band*Math.PI*2/3;
    for(let i=0;i<=30;i++)if(isWater(route.x,center+THREE.MathUtils.lerp(route.local,route.bank*.32,i/30),0.005))failures.push('Farm lane enters water');
  }
  const d=habitatGroup.userData;
  return {samples,failures,buildings:d.buildings,trees:d.trees,architecturalParts:d.architecturalParts,
    publicSpaces:d.publicSpaces,farms:farmlandPlots.length,accessRoutes:ruralRoutes.length,
    ruralHomes:d.buildingRecords.filter(r=>r.rural).length,neighborhoods:d.neighborhoods,railings:d.waterfrontRailSegments};
})()`);
assert.equal(settlements.failures.length,0,JSON.stringify(settlements.failures.slice(0,5)));
assert.equal(settlements.publicSpaces,24);
assert.ok(settlements.ruralHomes>10);
const viewBudgets = [];
for (const id of ['surface','bridge','cinema','axis','cutaway','section']) {
  run(`{const view=views.find(v=>v.id==='${id}');camera.position.copy(view.position);camera.up.copy(view.up);camera.fov=view.fov;camera.lookAt(view.target);camera.updateProjectionMatrix();updateDetailLevels();}`);
  const data = run('({cells:detailCells,root:colony})');
  let triangles = 0;
  data.root.traverseVisible(mesh => {
    if (mesh.isMesh) triangles += (mesh.geometry.index?.count || mesh.geometry.attributes.position.count) / 3 * (mesh.isInstancedMesh ? mesh.count : 1);
  });
  assert.ok(triangles < 5467800, 'LOD must reduce the expanded geometry budget');
  viewBudgets.push({ view: id, triangles, highCells: data.cells.filter(c => c.mesh.visible && c.mesh.geometry === c.high).length,
    lowCells: data.cells.filter(c => c.mesh.visible && c.mesh.geometry !== c.high).length, hiddenCells: data.cells.filter(c => !c.mesh.visible).length });
}

let coverageSamples = 0;
for (const hour of [0, 5.5, 6.7, 9, 12, 15, 17.3, 18.5, 23.9]) {
  for (const position of [[18.2,-4.8,0],[-18,2.4,4.1],[0,0,0],[27,-4,0]]) {
    run(`state.hour=${hour};camera.position.set(${position});updateSolarLighting(true);updateShadowRanges(true);scene.updateMatrixWorld(true);`);
    const { far, near, focus } = run('({far:solarLights,near:nearSolarLights,focus:shadowFocus.value})');
    for (let i = 0; i < 3; i++) {
      far[i].shadow.updateMatrices(far[i]); near[i].shadow.updateMatrices(near[i]);
      const df = far[i].position.clone().sub(far[i].target.position).normalize();
      const dn = near[i].position.clone().sub(near[i].target.position).normalize();
      assert.ok(df.distanceTo(dn) < 1e-10, 'Near/far radiance directions must agree');
      for (const x of [-28.125,0,28.125]) for (let j=0; j<72; j++) {
        const theta=j*Math.PI/36;
        const p=new THREE.Vector3(x,5.4*Math.cos(theta),5.4*Math.sin(theta)).project(far[i].shadow.camera);
        assert.ok(Math.max(Math.abs(p.x),Math.abs(p.y),Math.abs(p.z)) <= 1.000001, 'Broad shadow range covers the entire physical cylinder');
        coverageSamples++;
      }
      // The complete blend sphere must lie inside each local map's XY footprint.
      for (let j=0;j<72;j++) {
        const theta=j*Math.PI/36, p=focus.clone().add(new THREE.Vector3(0.64*Math.cos(theta),0.64*Math.sin(theta),0)).project(near[i].shadow.camera);
        assert.ok(Math.max(Math.abs(p.x),Math.abs(p.y)) < 1, 'No uncovered gap in the near/far blend');
      }
      const cam=near[i].shadow.camera;
      assert.equal((cam.right-cam.left)/near[i].shadow.mapSize.x*640,0.5);
    }
    if(hour===0) for(const light of [...far,...near]) assert.equal(light.intensity,0);
    // With unchanged geometry/camera/time, no depth map should refresh.
    run('[...solarLights,...nearSolarLights].forEach(l=>l.shadow.needsUpdate=false);renderer.shadowMap.needsUpdate=false;updateShadowRanges();');
    assert.equal(run('renderer.shadowMap.needsUpdate'),false);
  }
}
run('camera.position.set(70,20,0);updateShadowRanges();');
assert.equal(run('nearShadowWeight.value'),0);
run('camera.position.set(0,0,0);state.hour=12;updateSolarLighting(true);updateShadowRanges(true);');
const before=run('nearSolarLights[0].position.clone()');
run('nearSolarLights.forEach(l=>l.shadow.needsUpdate=false);camera.position.x+=0.000078125;updateShadowRanges();');
assert.ok(before.distanceTo(run('nearSolarLights[0].position'))<1e-12, 'Sub-texel movement must preserve the local shadow origin');
assert.equal(run('[...solarLights,...nearSolarLights].reduce((n,l)=>n+l.shadow.mapSize.x*l.shadow.mapSize.y,0)'),3*2048*4096);
console.log(JSON.stringify({revision:THREE.REVISION,cuts,settlements,viewBudgets,coverageSamples,nearShadowMetresPerTexel:0.5,defaults:'preserved',failures:[]},null,2));
