import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Breach Run",
  description: "A living pixel-art procedural demolition tech demo.",
  other: { "codex-preview": "development" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
